#!/bin/sh
###############################################################
# Service > systemd > dotnet.service
# Sample Project > /root
# ip Change > 192.168.3."You linux ip"
# MariaDB > user(root)/password(test) > table(test.board)
###############################################################
# 1. GitHub Repository Download
gitPath=https://github.com/KimNamKyu/Project.git
rootDir=/var/lib/jenkins/workspace/Test
projectDir=/Project
publishDir=/Project/bin/Debug/netcoreapp2.1/publish
serviceDir=/publish

if [ -d $rootDir$projectDir ]; then
  rm -Rf $rootDir$projectDir
fi

# 2. Project Build
git clone $gitPath
cd $rootDir$projectDir
dotnet build
dotnet publish

# 3. Service Shutdown
systemctl stop dotnet.service

# 4. Project Publish
ln -s $rootDir$publishDir $rootDir$serviceDir

# 5. Service Run
systemctl start dotnet.service

###############################################################
exit 0
